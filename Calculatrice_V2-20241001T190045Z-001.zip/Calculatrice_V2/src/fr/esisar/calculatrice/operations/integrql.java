package fr.esisar.calculatrice.operations;

import fr.esisar.calculatrice.CalculatriceException;

public class integrql implements Operation {

	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calculer(Double operande1, Double operande2) throws CalculatriceException {
		// TODO Auto-generated method stub
		return null;
	}

}
